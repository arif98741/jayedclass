<?php


class Implementclass implements Payment
{
    public function bkashPayment()
    {
        // TODO: Implement bkashPayment() method.
    }

    public function dbblPayment()
    {
        // TODO: Implement dbblPayment() method.
    }

    public function nogodPayment()
    {
        // TODO: Implement nogodPayment() method.
    }

}