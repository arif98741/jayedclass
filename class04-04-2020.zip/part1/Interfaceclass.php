<?php
Interface Payment{
    public function bkashPayment();
    public function dbblPayment();
    public function nogodPayment();
}