<?php
namespace abcde\abc;

class Calculator
{
    public function testmethod()
    {

    }
}